var express = require('express');
var path = require('path');
var fs = require('fs')
var bodyParser = require('body-parser');
var session = require('express-session')
var passport = require('passport')
var FacebookStrategy = require('passport-facebook').Strategy;
var LocalStrategy = require('passport-local').Strategy;


var routes = require('./routes/data');
var db = require('./db');

var app = express();
app.use(passport.initialize());
app.use(passport.session());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

//set the view path for html
app.set('views', path.join(__dirname, 'public'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));


var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.use(session({ secret: 'myenckey' }))

app.use('/', routes)



app.listen(3000)
