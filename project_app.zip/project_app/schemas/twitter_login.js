var mongoose = require('mongoose')

//var Schema =  mongoose.Schema;

var twitterSchema = new mongoose.Schema({

    twitterId: Number,
    token: String,
    name: String,
    email: String,
    password: String


})

module.exports = mongoose.model('twitter_login', twitterSchema)