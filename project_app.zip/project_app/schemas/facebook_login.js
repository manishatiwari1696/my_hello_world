var mongoose = require('mongoose')

//var Schema =  mongoose.Schema;

var facebookSchema = new mongoose.Schema({

    facebookId: Number,
    token: String,
    name: String,
    email: String,
    password: String,
    photo: String


})

module.exports = mongoose.model('facebook_login', facebookSchema)