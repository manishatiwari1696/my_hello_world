var mongoose = require('mongoose')

//var Schema =  mongoose.Schema;

var googleSchema = new mongoose.Schema({

    googleId: Number,
    token: String,
    name: String,
    email: String,
    password: String,
    path: String

})

module.exports = mongoose.model('google_login', googleSchema)