var mongoose = require('mongoose')

//var Schema =  mongoose.Schema;

var myappSchema = new mongoose.Schema({

    id: Number,

    name: String,
    email: String,
    password: String,
    filename: String,
    destination: String,
    path: String

})

module.exports = mongoose.model('myapp_login', myappSchema)