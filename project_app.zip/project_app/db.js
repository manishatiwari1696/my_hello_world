var mongoose = require('mongoose')

mongoose.connect('mongodb://localhost/project_app')

module.exports = mongoose.connection;