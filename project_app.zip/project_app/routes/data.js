
var express = require('express');
var router = express.Router();
var passport = require('passport')
var FacebookStrategy = require('passport-facebook').Strategy;
var TwitterStrategy = require('passport-twitter').Strategy;
var localStrategy = require('passport-local').Strategy;
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;
var nodemailer = require('nodemailer');
var multer = require('multer')
var path = require('path');
var session = ""
var facebook = require('../schemas/facebook_login')
var twitter = require("../schemas/twitter_login")
var myapp = require("../schemas/myapp_login")
var google = require("../schemas/google")



//for facebook login
var FacebookStrategy = require('passport-facebook').Strategy;

passport.use(new FacebookStrategy({
  clientID: 1517363681896610,
  clientSecret: 'b1f7ce9939fd7fbe73c3939492c43282',
  callbackURL: "http://localhost:3000/auth/facebook/callback",
  profileFields: ['id', 'displayName', 'photos', 'email']
},
  function (accessToken, refreshToken, profile, done) {
    console.log("this is profile details")
    console.log(profile.photos[0].value)
    facebook.findOne({ 'facebookId': profile.id }, function (err, user) {
      console.log(user)
      if (err) return done(err);

      if (!user) {
        var newFbUser = new facebook();
        newFbUser.facebookId = profile.id; // set the users facebook id                           
        newFbUser.name = profile.displayName;// look at the passport user profile to see how names are returned
        newFbUser.photo = profile.photos[0].value;
        // save our user to the database
        newFbUser.save(function (err) {
          if (err)
            throw err;
          return done(null, newFbUser);
        });
      }
      else {
        return done(err, user);
      }
    });

  }
));
router.get('/auth/facebook',
  passport.authenticate('facebook'));
router.get('/auth/facebook/callback',
  passport.authenticate('facebook', {
    failureRedirect: '/login'
  }),
  function (req, res) {
    console.log(req.session.passport.user)

    res.redirect("/facebookLogin_profile/" + req.session.passport.user);
  });
passport.serializeUser(function (newFbUser, done) {
  //console.log(req.session)
  done(null, newFbUser._id)
})
passport.deserializeUser(function (newFbUser, done) {
  done(null, newFbUser)
})






//for twitter login
passport.use(new TwitterStrategy({
  consumerKey: "DWsZ5VMYUdF3ipviQkyDL5dxD",
  consumerSecret: "IdImDMGO0VQSzGCvMI8KBOpYdgf3OpoFKkQS7zIrSamD6iZsmG",
  callbackURL: "http://localhost:3000/auth/twitter/callback"
},
  function (token, tokenSecret, profile, done) {
    twitter.findOne({ 'twitterId': profile.id }, function (err, user) {
      console.log(user)
      if (err) return done(err);

      if (!user) {
        console.log("new usesr")
        var newTwitterUser = new twitter();
        newTwitterUsertwitterId = profile.id; // set the users facebook id                           
        newTwitterUser.name = profile.displayName;// look at the passport user profile to see how names are returned
        newTwitterUser.save(function (err) {
          if (err)
            throw err;
          return done(null, newTwitterUser);
        });
      }
      else {
        console.log("old user")
        return done(err, user);
      }
    });
  }
));
router.get('/auth/twitter',
  passport.authenticate('twitter'));
router.get('/auth/twitter/callback',
  passport.authenticate('twitter', {
    failureRedirect: '/login'
  }),
  function (req, res) {
    console.log(req.session.passport.user)

    res.redirect("/twitterLogin_profile/" + req.session.passport.user);
  })
passport.serializeUser(function (newTwitterUser, done) {

  done(null, newTwitterUser._id)
})
passport.deserializeUser(function (newTwitterUser, done) {
  done(null, newTwitterUser)
})




//this route is for login with google account
passport.use(new GoogleStrategy({
  clientID: "1096165228298-tog70m2ads77og0qialod23rsgntbur0.apps.googleusercontent.com",
  clientSecret: "VTkjnnIWhrx_oZ7ptFeS8WjA",
  callbackURL: "http://localhost:3000/auth/google/callback"
},
  function (token, tokenSecret, profile, done) {
    google.findOne({ 'googleId': profile.id }, function (err, user) {
      console.log(user)
      if (err) return done(err);
      if (!user) {
        console.log("new usesr")
        var newgoogleUser = new google();
        newgoogleUser.googleId = profile.id; // set the users facebook id                           
        newgoogleUser.name = profile.displayName;// look at the passport user profile to see how names are returned
        // save our user to the database
        newgoogleUser.save(function (err) {
          if (err)
            throw err;
          // if successful, return the new user
          return done(null, newgoogleUser);
        });
      }
      else {
        console.log("old user")
        return done(err, user);
      }
    });
  }
));
router.get('/auth/google',
  passport.authenticate('google', { scope: ['https://www.googleapis.com/auth/plus.login'] }));
router.get('/auth/google/callback',
  passport.authenticate('google', {
    failureRedirect: '/login'
  }),
  function (req, res) {
    console.log(req.session.passport.user)

    res.redirect("/googleLogin_profile/" + req.session.passport.user);
  });
passport.serializeUser(function (newgoogleUser, done) {
  done(null, newgoogleUser._id)
})
passport.deserializeUser(function (newgoogleUser, done) {
  done(null, newgoogleUser)
})




//for validating whether the entered username or password is correct or not
// router.use('/signin', function(req, res){
//    var record = new myapp(req.body )
//     console.log(req.session);
//     myapp.findOne({email:record.email , password:record.password}, function (err, projectData) {
//     //console.log(projectData.length)
//     if(projectData)
//     {
//       console.log("lkdfnhjgsi")
//       req.session.username=record.email;
//       res.redirect('/profile/'+projectData._id)
//     }
//     else
//     {
//     res.json("u r not a user....")
//     }
//     })

// })



//for displaying the dashboard after google login
router.use('/googleLogin_profile/:id', function (req, res) {
  console.log(typeof req.params.id)
  google.findOne({ _id: req.params.id }, function (err, data) {
    res.render('starter.ejs', { datas: data.name })
  })

})


//for displaying the dashbord after facebook login
router.use('/facebookLogin_profile/:id', function (req, res) {
  console.log(typeof req.params.id)
  facebook.findOne({ _id: req.params.id }, function (err, data) {

    res.render('starter.ejs', { datas: data.name, pic: data.photo })
  })
})



//for displaying the dashbord after twitter login
router.use('/twitterLogin_profile/:id', function (req, res) {
  console.log(typeof req.params.id)
  twitter.findOne({ _id: req.params.id }, function (err, data) {
    res.render('starter.ejs', { datas: data.name })
  })
})


//for displaying dadhbord after simple login
router.use('/profile/:id', function (req, res) {
  console.log(req.params)
  console.log("session")
  console.log(req.session)
  session = req.session
  myapp.findOne({ _id: req.params.id }, function (err, data) {
    console.log(data)
    res.render('starter.ejs', { datas: data.name, pic: data.path })
  })
})



//for entering the email address at which reset password link is send
router.use('/forget_password', function (req, res) {
  res.render('enter_email.ejs')
})


//this route is for sending mail to the entered email addres by the user
router.post('/', function (req, res) {
  console.log(typeof req.body.username)
  var transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true, // true for 465, false for other ports
    auth: {
      user: 'tiwarimanisha1696@gmail.com', // generated ethereal user
      pass: 'mani9536950749' // generated ethereal password
    }
  });
  // setup email data with unicode symbols
  var mailOptions = {
    from: 'tiwarimanisha1696@gmail.com', // sender address
    to: req.body.username, // list of receivers
    subject: 'Hello ✔', // Subject line
    text: 'Hello hgjghworld?', // plain text body
    html: '<a href="http://localhost:3000/resetpassword/' + req.body.username + ' ">reset password</a>' // html body 
  };
  // send mail with defined transport object
  transporter.sendMail(mailOptions, function (error, response) {
    if (error) {
      console.log(error);
      res.end("error");
    }
    else {
      console.log(mailOptions)
      //console.log("Message sent: " + response.message);
      res.render('sendmail.ejs');
    }
  });
})



//this route is for reset the password by entering new password
router.use('/resetpassword/:username', function (req, res) {
  console.log(req.params)
  res.render('reset.ejs', { datas: req.params.username })
})



//this route is for updating the old password with the entred new password in the database
router.use('/reset_password', function (req, res) {
  console.log(req.body.username)
  //console.log(user_name)
  if (req.body.password == req.body.confirm_password) {
    myapp.find({ email: req.body.username }, function (err, data) {

      if (data.length != 0) {
        myapp.update({ email: req.body.username }, { password: req.body.password }, function (err, data) {
          console.log(data)
          console.log(err)
          res.render('done.ejs')
        })
      }
      else {
        res.send("sorry....you are not user.....")
      }

    })

  }
  else
    res.send('plzz confirm the right password')
})



//this route is for registering the new user and saving data in database
router.post('/register', function (req, res) {
  console.log(req.body)
  var storage = multer.diskStorage({
    destination: function (req, file, callback) {

      callback(null, './public/upload')
    },
    filename: function (req, file, callback) {
      console.log(file)
      callback(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
  })
  var upload = multer({
    storage: storage,

    fileFilter: function (req, file, callback) {
      var ext = path.extname(file.originalname)
      if (ext !== '.png' && ext !== '.jpg' && ext !== '.gif' && ext !== '.jpeg') {
        return callback(res.end('Only images are allowed'), null)
      }
      callback(null, true)
    }

  }).single('userFile')
  upload(req, res, function (err) {

    console.log(req.file)
    console.log("inside upload")
    console.log(req.body)
    myapp.findOne({ email: req.body.email }, function (err, data) {
      if (data) {
        res.send("this name email address is already present..plzz enter new email address...")
      }
      else {
        var newuser = new myapp();
        console.log(req.file.filename)
        newuser.name = req.body.name
        newuser.email = req.body.email
        newuser.password = req.body.password
        newuser.fileName = req.file.filename;
        newuser.destination = req.file.destination;
        newuser.originalname = req.file.originalname;
        newuser.path = "/upload/" + req.file.filename;
        console.log(newuser)

        newuser.save(function (err, data) {

          console.log(data)

          if (data.length == 0) {
            res.send("sorry...you are not registered...plzz try again...")
          }
          else {
            res.redirect('/')
          }
        })
      }
    })
  })
})


//this route is for layout of register form
router.use('/register', function (req, res) {
  res.render('register.ejs')
})




//validate the credentials from the html form with databse
passport.use(new localStrategy(function (username, password, done) {
  console.log("kugiugy")
  myapp.findOne({ email: username, password: password }, function (err, projectData) {

    console.log("geduiqwgiu" + projectData)
    console.log(err)
    var id = projectData._id
    console.log(id)
    if (projectData.length != 0) {
      return done(null, { id })
    }
    else {
      return done(null, false)
    }
    console.log(req.session.username + " welcome.....and session is created")
  })
}))
passport.serializeUser(function (user, done) {
  console.log("fdbghdf")
  console.log(user.id)
  done(null, user.id)
})
passport.deserializeUser(function (user, done) {
  done(null, { user: username })
})


//this route is for simple singin
router.post('/signin', passport.authenticate('local',
  {

    failureRedirect: '/login'
  }),
  function (req, res) {
    console.log(req.session.passport)

    res.redirect("/profile/" + req.session.passport.user);
  });


 //this route is for signout from account
 router.use('/logout', function (req, res) 
 {

  req.logout();

  res.redirect('/')
  })

router.use('/error', function (req, res) {
  res.json('not registred......')
})


//for home page layout
router.use('/', function (req, res) {
  res.render("login.ejs")
})

module.exports = router;